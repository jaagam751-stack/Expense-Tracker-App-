import 'dart:convert';
import 'package:flutter/foundation.dart'; // kIsWeb
import 'package:geolocator/geolocator.dart';
import 'package:http/http.dart' as http;
import '../models/location_result.dart';

/// GPS + Reverse-Geocoding Service.
///
/// Uses [geolocator] for coordinates (works on Android, iOS & Web).
/// Uses OpenStreetMap Nominatim API for city names (works on all platforms).
class LocationService {
  static final LocationService instance = LocationService._init();
  LocationService._init();

  /// Checks permissions, fetches GPS position, and reverse-geocodes the city.
  /// Returns a [LocationResult] with either success data or a user-friendly error.
  Future<LocationResult> getCurrentLocation() async {
    // ── Step 1: Check if location services (GPS) are enabled ──
    bool serviceEnabled = await Geolocator.isLocationServiceEnabled();
    if (!serviceEnabled) {
      return const LocationResult(
        errorMessage:
            '📍 Location services are disabled.\nPlease turn on GPS in device settings.',
      );
    }

    // ── Step 2: Check / request permission ──
    LocationPermission permission = await Geolocator.checkPermission();

    if (permission == LocationPermission.denied) {
      permission = await Geolocator.requestPermission();
      if (permission == LocationPermission.denied) {
        return const LocationResult(
          errorMessage:
              '🚫 Location permission denied.\nPlease allow location access and try again.',
        );
      }
    }

    if (permission == LocationPermission.deniedForever) {
      return const LocationResult(
        errorMessage:
            '⛔ Permission permanently denied.\nGo to Settings → App → Permissions → Location.',
      );
    }

    // ── Step 3: Fetch current position ──
    try {
      final Position position = await Geolocator.getCurrentPosition(
        locationSettings: const LocationSettings(
          accuracy: LocationAccuracy.high,
          timeLimit: Duration(seconds: 15),
        ),
      );

      // ── Step 4: Reverse-geocode for city name (skip on Web if needed) ──
      String? cityName = await _reverseGeocode(
        position.latitude,
        position.longitude,
      );

      return LocationResult(
        lat: position.latitude,
        lng: position.longitude,
        city: cityName,
      );
    } catch (e) {
      return LocationResult(
        errorMessage: '❌ Error fetching location:\n${e.toString()}',
      );
    }
  }

  /// Calls OpenStreetMap Nominatim API to get a human-readable city name.
  /// Returns null if the call fails (network issue, etc.).
  Future<String?> _reverseGeocode(double lat, double lng) async {
    try {
      final uri = Uri.parse(
        'https://nominatim.openstreetmap.org/reverse'
        '?lat=$lat&lon=$lng&format=json',
      );
      final response = await http
          .get(uri, headers: {'User-Agent': 'TrackerApp/2.0'})
          .timeout(const Duration(seconds: 8));

      if (response.statusCode == 200) {
        final data = json.decode(response.body);
        final address = data['address'] as Map<String, dynamic>?;
        if (address != null) {
          // Pick the most meaningful label available
          final city = address['city'] ??
              address['town'] ??
              address['village'] ??
              address['state_district'];
          final state = address['state'] ?? '';
          final country = address['country'] ?? '';
          return [city, state, country]
              .where((e) => e != null && (e as String).isNotEmpty)
              .join(', ');
        }
      }
    } catch (_) {
      // Silently fail — city is optional
    }
    return null;
  }
}
