/// Rule-based Chatbot Service.
///
/// API-READY: The [getResponse] method is async and returns a Future<String>.
/// To connect OpenAI later, just replace the body of [getResponse] with an
/// HTTP POST to the OpenAI Chat Completions API. No UI changes needed.
class ChatbotService {
  static final ChatbotService instance = ChatbotService._init();
  ChatbotService._init();

  // ── Intent map: keywords → canned response ──────────────────────────────
  static const List<Map<String, dynamic>> _intents = [
    {
      'keywords': ['hi', 'hello', 'hey', 'good morning', 'good evening', 'howdy', 'start'],
      'response':
          '👋 Hey there! I\'m your Expense Assistant 🤖\n\nI can help you with:\n'
          '• ➕ Adding expenses / income\n'
          '• 📊 Understanding your dashboard\n'
          '• 📍 Using the GPS feature\n'
          '• 🌟 Accessing the AR experience\n'
          '• 💡 Saving & budgeting tips\n\n'
          'What would you like to know?',
    },
    {
      'keywords': ['add', 'new expense', 'new transaction', 'record', 'log', 'spend', 'spent', 'purchase'],
      'response':
          '➕ How to add a transaction:\n\n'
          '1. Tap the ➕ FAB on the Home screen\n'
          '2. Enter a title (e.g. "Lunch")\n'
          '3. Enter the amount\n'
          '4. Choose Income or Expense\n'
          '5. Tap Save ✅\n\n'
          'It appears instantly in Recent Transactions! 🧾',
    },
    {
      'keywords': ['dashboard', 'spending', 'chart', 'analytics', 'overview', 'show my', 'balance', 'stats'],
      'response':
          '📊 Your dashboard is on the Home screen!\n\n'
          'It shows:\n'
          '• 💰 Total Balance card\n'
          '• 🥧 Income vs Expense pie chart (animated!)\n'
          '• 📉 Monthly analytics bars\n'
          '• 🧾 All recent transactions\n\n'
          'Just go back to Home to see everything live!',
    },
    {
      'keywords': ['income', 'salary', 'earn', 'earning', 'source', 'revenue'],
      'response':
          '💵 Income Tips:\n\n'
          '• Log all income sources regularly\n'
          '• Track freelance & side gigs too\n'
          '• Compare monthly income trends\n\n'
          'Tap ➕ → select "Income" to add any income entry!',
    },
    {
      'keywords': ['save', 'saving', 'budget', 'budgeting', 'tip', 'advice', 'how to', 'reduce', 'cut'],
      'response':
          '💡 Smart Budgeting Tips:\n\n'
          '1️⃣ Follow the 50/30/20 rule:\n'
          '   → 50% needs, 30% wants, 20% savings\n\n'
          '2️⃣ Track every rupee — even small ones\n\n'
          '3️⃣ Review your pie chart weekly\n\n'
          '4️⃣ Set a daily spending limit\n\n'
          'Consistency is your superpower! 🎯',
    },
    {
      'keywords': ['gps', 'location', 'where', 'city', 'coordinates', 'latitude', 'longitude', 'map'],
      'response':
          '📍 GPS Location Feature:\n\n'
          'Scroll down on the Home screen to find the GPS card.\n\n'
          'Tap "Get Current Location" to see:\n'
          '• 🛰️ Your latitude & longitude\n'
          '• 🏙️ Your current city name\n\n'
          'Make sure GPS is enabled in device settings! 🔧',
    },
    {
      'keywords': ['ar', 'augmented reality', '3d', 'coin', 'hologram', 'reality', 'view in ar'],
      'response':
          '🌟 AR Experience:\n\n'
          'Tap "🌟 View in AR" in the drawer menu (☰ top-left).\n\n'
          'You\'ll see:\n'
          '• 🪙 A rotating 3D gold coin\n'
          '• 💹 Holographic expense cards\n'
          '• 📡 Animated scan beams\n'
          '• Live income & expense data in AR!\n\n'
          'Our coolest feature! ✨',
    },
    {
      'keywords': ['dark', 'light', 'theme', 'mode', 'night', 'appearance'],
      'response':
          '🌙 Dark / Light Mode:\n\n'
          '1. Open the drawer menu (☰ top-left)\n'
          '2. Toggle the "Dark Mode" switch\n\n'
          'The entire app switches instantly! 🎨',
    },
    {
      'keywords': ['logout', 'log out', 'sign out', 'exit', 'switch account'],
      'response':
          '🚪 To logout:\n\n'
          '1. Open the drawer (☰)\n'
          '2. Tap "Logout"\n\n'
          'You\'ll return to the Login screen safely.',
    },
    {
      'keywords': ['thanks', 'thank you', 'thx', 'bye', 'goodbye', 'see you', 'great'],
      'response':
          '😊 You\'re welcome! Happy budgeting! 💰\n\n'
          'Feel free to ask anything anytime. See you! 👋',
    },
    {
      'keywords': ['help', 'what can you do', 'commands', 'options', 'menu'],
      'response':
          '🤖 Here\'s what I can help with:\n\n'
          '• "How to add expense?"\n'
          '• "Show my spending"\n'
          '• "Give saving tips"\n'
          '• "How to use GPS?"\n'
          '• "What is AR?"\n'
          '• "How to toggle dark mode?"\n'
          '• "How to logout?"\n\n'
          'Just type naturally! 😊',
    },
  ];

  /// Get a chatbot response for the user's [message].
  ///
  /// ─── HOW TO UPGRADE TO OPENAI ────────────────────────────────────────────
  /// Replace this entire method body with:
  ///
  /// ```dart
  /// final response = await http.post(
  ///   Uri.parse('https://api.openai.com/v1/chat/completions'),
  ///   headers: {'Authorization': 'Bearer YOUR_KEY', 'Content-Type': 'application/json'},
  ///   body: json.encode({
  ///     'model': 'gpt-3.5-turbo',
  ///     'messages': [{'role': 'user', 'content': message}],
  ///   }),
  /// );
  /// final data = json.decode(response.body);
  /// return data['choices'][0]['message']['content'];
  /// ```
  /// ─────────────────────────────────────────────────────────────────────────
  Future<String> getResponse(String message) async {
    // Simulate a short typing delay for realism
    await Future.delayed(const Duration(milliseconds: 700));

    final lowerMsg = message.toLowerCase().trim();

    // Match input against each intent's keywords
    for (final intent in _intents) {
      final keywords = intent['keywords'] as List<String>;
      for (final keyword in keywords) {
        if (lowerMsg.contains(keyword)) {
          return intent['response'] as String;
        }
      }
    }

    // Fallback: no match found
    return '🤔 Hmm, I\'m not sure about that yet!\n\n'
        'Try asking:\n'
        '• "How to add expense?"\n'
        '• "Show my balance"\n'
        '• "Give me saving tips"\n'
        '• "How to use GPS?"\n\n'
        'Or type "help" to see all options! 😊';
  }
}
