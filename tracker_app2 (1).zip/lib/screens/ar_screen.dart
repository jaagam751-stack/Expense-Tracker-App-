import 'dart:math';
import 'package:flutter/material.dart';
import '../widgets/ar_coin_widget.dart';
import '../services/database_helper.dart';

/// AR Experience Screen — Simulated Augmented Reality.
///
/// Uses only Flutter's animation & CustomPainter — no native AR plugins.
/// Runs crash-free on any Android/iOS device or emulator.
///
/// Features:
///   🪙  Rotating 3D gold coin (ArCoinWidget)
///   💹  Floating holographic data cards (income / expense / balance)
///   📡  Animated scan-beam sweep (CustomPainter)
///   ✨  Glowing particle field background
class ArScreen extends StatefulWidget {
  const ArScreen({Key? key}) : super(key: key);

  @override
  _ArScreenState createState() => _ArScreenState();
}

class _ArScreenState extends State<ArScreen> with TickerProviderStateMixin {
  // ── Animations ──────────────────────────────────────────────────────────
  late AnimationController _scanCtrl;   // Scan beam sweep
  late AnimationController _bobCtrl;    // Cards bobbing up/down
  late AnimationController _fadeCtrl;   // Initial fade-in
  late AnimationController _glowCtrl;   // Glow pulse

  late Animation<double> _bobAnim;
  late Animation<double> _fadeAnim;
  late Animation<double> _glowAnim;

  // ── Data ────────────────────────────────────────────────────────────────
  double get income => DatabaseHelper.instance
      .getTransactions()
      .where((e) => e.type == 'income')
      .fold(0, (s, e) => s + e.amount);

  double get expense => DatabaseHelper.instance
      .getTransactions()
      .where((e) => e.type == 'expense')
      .fold(0, (s, e) => s + e.amount);

  double get balance => income - expense;

  @override
  void initState() {
    super.initState();

    _scanCtrl = AnimationController(
      vsync: this,
      duration: const Duration(seconds: 3),
    )..repeat();

    _bobCtrl = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 2200),
    )..repeat(reverse: true);

    _fadeCtrl = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 800),
    )..forward();

    _glowCtrl = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 1400),
    )..repeat(reverse: true);

    _bobAnim = Tween<double>(begin: -8, end: 8).animate(
      CurvedAnimation(parent: _bobCtrl, curve: Curves.easeInOut),
    );
    _fadeAnim = CurvedAnimation(parent: _fadeCtrl, curve: Curves.easeIn);
    _glowAnim = Tween<double>(begin: 0.5, end: 1.0).animate(
      CurvedAnimation(parent: _glowCtrl, curve: Curves.easeInOut),
    );
  }

  @override
  void dispose() {
    _scanCtrl.dispose();
    _bobCtrl.dispose();
    _fadeCtrl.dispose();
    _glowCtrl.dispose();
    super.dispose();
  }

  // ── Build ────────────────────────────────────────────────────────────────
  @override
  Widget build(BuildContext context) {
    final size = MediaQuery.of(context).size;

    return Scaffold(
      body: Stack(
        fit: StackFit.expand,
        children: [
          // ── 1. Dark AR Background with grid ───────────────────────────
          _ArBackground(scanCtrl: _scanCtrl),

          // ── 2. All AR content fades in ─────────────────────────────────
          FadeTransition(
            opacity: _fadeAnim,
            child: SafeArea(
              child: Column(
                children: [
                  // AppBar row
                  _ArAppBar(context: context),

                  const SizedBox(height: 20),

                  // ── 3. Rotating 3D Coin ──────────────────────────────
                  AnimatedBuilder(
                    animation: _bobAnim,
                    builder: (_, child) => Transform.translate(
                      offset: Offset(0, _bobAnim.value * 0.5),
                      child: child,
                    ),
                    child: const ArCoinWidget(size: 160),
                  ),

                  const SizedBox(height: 8),

                  // Coin label
                  AnimatedBuilder(
                    animation: _glowAnim,
                    builder: (_, __) => Text(
                      '◉  HOLOGRAPHIC COIN  ◉',
                      style: TextStyle(
                        color: Color.lerp(
                          const Color(0xFF00E5FF),
                          Colors.white,
                          _glowAnim.value,
                        ),
                        fontSize: 11,
                        fontWeight: FontWeight.w700,
                        letterSpacing: 2.5,
                      ),
                    ),
                  ),

                  const SizedBox(height: 28),

                  // ── 4. Floating Holographic Cards ────────────────────
                  AnimatedBuilder(
                    animation: _bobAnim,
                    builder: (_, __) {
                      return Padding(
                        padding: const EdgeInsets.symmetric(horizontal: 20),
                        child: Column(
                          children: [
                            // Balance card (main, larger)
                            Transform.translate(
                              offset: Offset(0, _bobAnim.value),
                              child: _HolographicCard(
                                label: 'NET BALANCE',
                                value: '₹ ${balance.toStringAsFixed(2)}',
                                icon: Icons.account_balance_wallet_rounded,
                                color: balance >= 0
                                    ? const Color(0xFF00E676)
                                    : const Color(0xFFFF5252),
                                glowAnim: _glowAnim,
                                large: true,
                              ),
                            ),
                            const SizedBox(height: 14),
                            Row(
                              children: [
                                // Income card
                                Expanded(
                                  child: Transform.translate(
                                    offset: Offset(0, -_bobAnim.value),
                                    child: _HolographicCard(
                                      label: 'INCOME',
                                      value: '₹ ${income.toStringAsFixed(0)}',
                                      icon: Icons.trending_up_rounded,
                                      color: const Color(0xFF00E676),
                                      glowAnim: _glowAnim,
                                    ),
                                  ),
                                ),
                                const SizedBox(width: 14),
                                // Expense card
                                Expanded(
                                  child: Transform.translate(
                                    offset:
                                        Offset(0, _bobAnim.value * 0.7),
                                    child: _HolographicCard(
                                      label: 'EXPENSE',
                                      value:
                                          '₹ ${expense.toStringAsFixed(0)}',
                                      icon: Icons.trending_down_rounded,
                                      color: const Color(0xFFFF5252),
                                      glowAnim: _glowAnim,
                                    ),
                                  ),
                                ),
                              ],
                            ),
                          ],
                        ),
                      );
                    },
                  ),

                  const Spacer(),

                  // ── 5. Bottom status bar ──────────────────────────────
                  _ArStatusBar(glowAnim: _glowAnim),
                  const SizedBox(height: 16),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }
}

// ─────────────────────────────────────────────────────────────────────────────
// Sub-widgets & Painters
// ─────────────────────────────────────────────────────────────────────────────

/// App-bar row for the AR screen
class _ArAppBar extends StatelessWidget {
  final BuildContext context;
  const _ArAppBar({required this.context});

  @override
  Widget build(BuildContext _) {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
      child: Row(
        children: [
          IconButton(
            icon: const Icon(Icons.arrow_back_ios_rounded, color: Colors.white),
            onPressed: () => Navigator.pop(context),
          ),
          const Expanded(
            child: Text(
              '🌟  AR Experience',
              style: TextStyle(
                color: Colors.white,
                fontSize: 20,
                fontWeight: FontWeight.bold,
                letterSpacing: 0.8,
              ),
              textAlign: TextAlign.center,
            ),
          ),
          const Icon(Icons.view_in_ar_rounded, color: Color(0xFF00E5FF), size: 28),
          const SizedBox(width: 8),
        ],
      ),
    );
  }
}

/// Dark AR-like background with animated grid and scan beam
class _ArBackground extends StatelessWidget {
  final AnimationController scanCtrl;
  const _ArBackground({required this.scanCtrl});

  @override
  Widget build(BuildContext context) {
    return Stack(
      fit: StackFit.expand,
      children: [
        // Deep space gradient
        Container(
          decoration: const BoxDecoration(
            gradient: LinearGradient(
              begin: Alignment.topLeft,
              end: Alignment.bottomRight,
              colors: [
                Color(0xFF0A0A1A),
                Color(0xFF0D0D2B),
                Color(0xFF050510),
              ],
            ),
          ),
        ),
        // Grid overlay
        CustomPaint(painter: _GridPainter()),
        // Animated scan beam
        AnimatedBuilder(
          animation: scanCtrl,
          builder: (_, __) => CustomPaint(
            painter: _ScanBeamPainter(progress: scanCtrl.value),
          ),
        ),
        // Particle field (static dots)
        CustomPaint(painter: _ParticleFieldPainter()),
      ],
    );
  }
}

/// AR-style perspective grid
class _GridPainter extends CustomPainter {
  @override
  void paint(Canvas canvas, Size size) {
    final paint = Paint()
      ..color = const Color(0xFF00E5FF).withOpacity(0.07)
      ..strokeWidth = 0.6;

    const spacing = 40.0;
    for (double x = 0; x < size.width; x += spacing) {
      canvas.drawLine(
          Offset(x, 0), Offset(x, size.height), paint);
    }
    for (double y = 0; y < size.height; y += spacing) {
      canvas.drawLine(
          Offset(0, y), Offset(size.width, y), paint);
    }
  }

  @override
  bool shouldRepaint(_) => false;
}

/// Moving horizontal scan beam (green like AR scanners)
class _ScanBeamPainter extends CustomPainter {
  final double progress;
  _ScanBeamPainter({required this.progress});

  @override
  void paint(Canvas canvas, Size size) {
    final y = progress * size.height;
    final beamPaint = Paint()
      ..shader = LinearGradient(
        begin: Alignment.topCenter,
        end: Alignment.bottomCenter,
        colors: [
          Colors.transparent,
          const Color(0xFF00E5FF).withOpacity(0.35),
          const Color(0xFF00E5FF).withOpacity(0.12),
          Colors.transparent,
        ],
        stops: const [0.0, 0.45, 0.55, 1.0],
      ).createShader(Rect.fromLTWH(0, y - 40, size.width, 80));

    canvas.drawRect(
      Rect.fromLTWH(0, y - 40, size.width, 80),
      beamPaint,
    );

    // Bright leading edge line
    canvas.drawLine(
      Offset(0, y),
      Offset(size.width, y),
      Paint()
        ..color = const Color(0xFF00E5FF).withOpacity(0.7)
        ..strokeWidth = 1.5,
    );
  }

  @override
  bool shouldRepaint(_ScanBeamPainter old) => old.progress != progress;
}

/// Star/particle field in background
class _ParticleFieldPainter extends CustomPainter {
  @override
  void paint(Canvas canvas, Size size) {
    final rng = Random(42); // Fixed seed for consistent layout
    for (int i = 0; i < 60; i++) {
      final x = rng.nextDouble() * size.width;
      final y = rng.nextDouble() * size.height;
      final r = rng.nextDouble() * 1.5 + 0.3;
      canvas.drawCircle(
        Offset(x, y),
        r,
        Paint()
          ..color =
              Colors.white.withOpacity(rng.nextDouble() * 0.4 + 0.1),
      );
    }
  }

  @override
  bool shouldRepaint(_) => false;
}

/// Glowing holographic data card
class _HolographicCard extends StatelessWidget {
  final String label;
  final String value;
  final IconData icon;
  final Color color;
  final Animation<double> glowAnim;
  final bool large;

  const _HolographicCard({
    required this.label,
    required this.value,
    required this.icon,
    required this.color,
    required this.glowAnim,
    this.large = false,
  });

  @override
  Widget build(BuildContext context) {
    return AnimatedBuilder(
      animation: glowAnim,
      builder: (_, __) {
        return Container(
          width: double.infinity,
          padding: EdgeInsets.all(large ? 18 : 14),
          decoration: BoxDecoration(
            color: Colors.black.withOpacity(0.55),
            borderRadius: BorderRadius.circular(16),
            border: Border.all(
              color: color.withOpacity(0.5 + glowAnim.value * 0.4),
              width: 1.5,
            ),
            boxShadow: [
              BoxShadow(
                color: color.withOpacity(0.25 * glowAnim.value),
                blurRadius: 20,
                spreadRadius: 2,
              ),
            ],
          ),
          child: Row(
            children: [
              Container(
                padding: const EdgeInsets.all(10),
                decoration: BoxDecoration(
                  color: color.withOpacity(0.15),
                  borderRadius: BorderRadius.circular(12),
                  border: Border.all(
                      color: color.withOpacity(0.4), width: 1),
                ),
                child: Icon(icon, color: color, size: large ? 28 : 22),
              ),
              const SizedBox(width: 14),
              Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    label,
                    style: TextStyle(
                      color: color.withOpacity(0.8),
                      fontSize: 10,
                      fontWeight: FontWeight.w700,
                      letterSpacing: 2,
                    ),
                  ),
                  const SizedBox(height: 4),
                  Text(
                    value,
                    style: TextStyle(
                      color: Colors.white,
                      fontSize: large ? 26 : 20,
                      fontWeight: FontWeight.bold,
                    ),
                  ),
                ],
              ),
              const Spacer(),
              // Corner bracket decorations
              Column(
                children: [
                  _Corner(color: color),
                ],
              ),
            ],
          ),
        );
      },
    );
  }
}

/// AR corner bracket decoration
class _Corner extends StatelessWidget {
  final Color color;
  const _Corner({required this.color});

  @override
  Widget build(BuildContext context) {
    return CustomPaint(
      size: const Size(20, 20),
      painter: _CornerPainter(color: color),
    );
  }
}

class _CornerPainter extends CustomPainter {
  final Color color;
  _CornerPainter({required this.color});

  @override
  void paint(Canvas canvas, Size size) {
    final paint = Paint()
      ..color = color
      ..strokeWidth = 2
      ..style = PaintingStyle.stroke;
    const len = 8.0;
    canvas.drawLine(Offset.zero, Offset(len, 0), paint);
    canvas.drawLine(Offset.zero, Offset(0, len), paint);
    canvas.drawLine(
        Offset(size.width, size.height), Offset(size.width - len, size.height), paint);
    canvas.drawLine(
        Offset(size.width, size.height), Offset(size.width, size.height - len), paint);
  }

  @override
  bool shouldRepaint(_) => false;
}

/// Bottom status bar mimicking AR heads-up display
class _ArStatusBar extends StatelessWidget {
  final Animation<double> glowAnim;
  const _ArStatusBar({required this.glowAnim});

  @override
  Widget build(BuildContext context) {
    return AnimatedBuilder(
      animation: glowAnim,
      builder: (_, __) {
        return Container(
          margin: const EdgeInsets.symmetric(horizontal: 20),
          padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 10),
          decoration: BoxDecoration(
            color: Colors.black.withOpacity(0.6),
            borderRadius: BorderRadius.circular(30),
            border: Border.all(
              color: const Color(0xFF00E5FF)
                  .withOpacity(0.3 + 0.3 * glowAnim.value),
            ),
          ),
          child: Row(
            mainAxisAlignment: MainAxisAlignment.spaceEvenly,
            children: [
              _statusChip('📡', 'AR ACTIVE', const Color(0xFF00E5FF)),
              _dot(),
              _statusChip('🛰️', 'TRACKING', const Color(0xFF00E676)),
              _dot(),
              _statusChip('💹', 'LIVE DATA', const Color(0xFFFFB300)),
            ],
          ),
        );
      },
    );
  }

  Widget _statusChip(String emoji, String label, Color color) {
    return Row(
      mainAxisSize: MainAxisSize.min,
      children: [
        Text(emoji, style: const TextStyle(fontSize: 12)),
        const SizedBox(width: 4),
        Text(
          label,
          style: TextStyle(
              color: color,
              fontSize: 10,
              fontWeight: FontWeight.w700,
              letterSpacing: 1),
        ),
      ],
    );
  }

  Widget _dot() => Container(
      width: 3,
      height: 3,
      decoration: BoxDecoration(
          color: Colors.white38, shape: BoxShape.circle));
}
