import 'package:flutter/material.dart';
import 'dart:math';

/// Animated 3D coin widget using only Flutter's CustomPainter.
/// No native plugins — runs on Android, iOS, and Web.
/// Used inside ArScreen to create the "holographic coin" effect.
class ArCoinWidget extends StatefulWidget {
  final double size;
  const ArCoinWidget({Key? key, this.size = 150}) : super(key: key);

  @override
  _ArCoinWidgetState createState() => _ArCoinWidgetState();
}

class _ArCoinWidgetState extends State<ArCoinWidget>
    with SingleTickerProviderStateMixin {
  late AnimationController _spinCtrl;

  @override
  void initState() {
    super.initState();
    _spinCtrl = AnimationController(
      vsync: this,
      duration: const Duration(seconds: 3),
    )..repeat();
  }

  @override
  void dispose() {
    _spinCtrl.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return AnimatedBuilder(
      animation: _spinCtrl,
      builder: (_, __) => CustomPaint(
        size: Size(widget.size, widget.size),
        painter: _CoinPainter(animValue: _spinCtrl.value),
      ),
    );
  }
}

class _CoinPainter extends CustomPainter {
  final double animValue;
  _CoinPainter({required this.animValue});

  @override
  void paint(Canvas canvas, Size size) {
    final cx = size.width / 2;
    final cy = size.height / 2;
    final r = size.width / 2 * 0.85;

    // The coin "flip" — squish X axis using cosine to fake 3D rotation
    final scaleX = cos(animValue * 2 * pi).abs().clamp(0.05, 1.0);
    final isHeads = cos(animValue * 2 * pi) >= 0;

    canvas.save();
    canvas.translate(cx, cy);
    canvas.scale(scaleX, 1.0);
    canvas.translate(-cx, -cy);

    // Drop shadow beneath the coin
    final shadowPaint = Paint()
      ..color = Colors.black.withOpacity(0.30)
      ..maskFilter = const MaskFilter.blur(BlurStyle.normal, 12);
    canvas.drawOval(
      Rect.fromCenter(
          center: Offset(cx, cy + r * 0.82),
          width: r * 1.7,
          height: r * 0.38),
      shadowPaint,
    );

    // Coin face gradient (gold front / silver back)
    final gradient = RadialGradient(
      center: const Alignment(-0.35, -0.35),
      radius: 0.85,
      colors: isHeads
          ? [
              const Color(0xFFFFE566),
              const Color(0xFFFFB300),
              const Color(0xFF8B6914),
            ]
          : [
              const Color(0xFFE0E0E0),
              const Color(0xFF9E9E9E),
              const Color(0xFF424242),
            ],
    );
    final coinPaint = Paint()
      ..shader =
          gradient.createShader(Rect.fromCircle(center: Offset(cx, cy), radius: r));
    canvas.drawCircle(Offset(cx, cy), r, coinPaint);

    // Rim highlight
    final rimPaint = Paint()
      ..style = PaintingStyle.stroke
      ..strokeWidth = 3
      ..color = Colors.white.withOpacity(0.35);
    canvas.drawCircle(Offset(cx, cy), r - 1.5, rimPaint);

    // Inner circle ring for depth
    final innerPaint = Paint()
      ..style = PaintingStyle.stroke
      ..strokeWidth = 1.5
      ..color = Colors.white.withOpacity(0.20);
    canvas.drawCircle(Offset(cx, cy), r * 0.65, innerPaint);

    // Center symbol — only draw when coin is facing us enough
    if (scaleX > 0.15) {
      final symbol = isHeads ? '₹' : '💰';
      final tp = TextPainter(
        text: TextSpan(
          text: symbol,
          style: TextStyle(
            fontSize: r * 0.68,
            color: Colors.white.withOpacity(0.95),
            fontWeight: FontWeight.w900,
          ),
        ),
        textDirection: TextDirection.ltr,
      )..layout();
      tp.paint(canvas, Offset(cx - tp.width / 2, cy - tp.height / 2));
    }

    canvas.restore();
  }

  @override
  bool shouldRepaint(_CoinPainter old) => old.animValue != animValue;
}
