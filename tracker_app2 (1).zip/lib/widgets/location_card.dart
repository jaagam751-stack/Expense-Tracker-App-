import 'package:flutter/material.dart';
import '../models/location_result.dart';
import '../services/location_service.dart';

/// GPS Location Card widget.
/// Matches the existing app's indigo-blue gradient card design.
/// Shows: lat, lng, city name (or user-friendly error states).
class LocationCard extends StatefulWidget {
  const LocationCard({Key? key}) : super(key: key);

  @override
  _LocationCardState createState() => _LocationCardState();
}

class _LocationCardState extends State<LocationCard>
    with SingleTickerProviderStateMixin {
  LocationResult? _result;
  bool _isLoading = false;

  // Pulse animation for the GPS icon
  late AnimationController _pulseCtrl;
  late Animation<double> _pulseAnim;

  @override
  void initState() {
    super.initState();
    _pulseCtrl = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 900),
    )..repeat(reverse: true);
    _pulseAnim = Tween<double>(begin: 0.85, end: 1.15).animate(
      CurvedAnimation(parent: _pulseCtrl, curve: Curves.easeInOut),
    );
  }

  @override
  void dispose() {
    _pulseCtrl.dispose();
    super.dispose();
  }

  // ── Fetch GPS location via LocationService ──────────────────────────────
  Future<void> _fetchLocation() async {
    setState(() => _isLoading = true);
    final result = await LocationService.instance.getCurrentLocation();
    setState(() {
      _result = result;
      _isLoading = false;
    });
  }

  @override
  Widget build(BuildContext context) {
    return Container(
      margin: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
      padding: const EdgeInsets.all(20),
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(20),
        // Matches the app's existing indigo → blue gradient palette
        gradient: const LinearGradient(
          colors: [Color(0xFF1A237E), Color(0xFF1976D2)],
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
        ),
        boxShadow: [
          BoxShadow(
            color: Colors.indigo.withOpacity(0.45),
            blurRadius: 14,
            offset: const Offset(0, 7),
          ),
        ],
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          // ── Header ──────────────────────────────────────────────────────
          Row(
            children: [
              ScaleTransition(
                scale: _pulseAnim,
                child: const Icon(Icons.location_on_rounded,
                    color: Colors.white, size: 26),
              ),
              const SizedBox(width: 10),
              const Text(
                '📍 GPS Location',
                style: TextStyle(
                  color: Colors.white,
                  fontSize: 17,
                  fontWeight: FontWeight.bold,
                ),
              ),
            ],
          ),

          const SizedBox(height: 16),

          // ── Content area (idle / loading / success / error) ─────────────
          _buildContent(),

          const SizedBox(height: 16),

          // ── Action Button ────────────────────────────────────────────────
          SizedBox(
            width: double.infinity,
            child: ElevatedButton.icon(
              onPressed: _isLoading ? null : _fetchLocation,
              icon: _isLoading
                  ? const SizedBox(
                      width: 16,
                      height: 16,
                      child: CircularProgressIndicator(
                          color: Colors.white, strokeWidth: 2),
                    )
                  : const Icon(Icons.my_location, color: Colors.white, size: 18),
              label: Text(
                _isLoading ? 'Fetching location…' : 'Get Current Location',
                style: const TextStyle(
                    color: Colors.white, fontWeight: FontWeight.bold),
              ),
              style: ElevatedButton.styleFrom(
                backgroundColor: Colors.white.withOpacity(0.2),
                padding: const EdgeInsets.symmetric(vertical: 12),
                shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(12),
                  side:
                      BorderSide(color: Colors.white.withOpacity(0.45)),
                ),
                elevation: 0,
              ),
            ),
          ),
        ],
      ),
    );
  }

  // ── Builds the content area based on current state ────────────────────
  Widget _buildContent() {
    // Idle state
    if (_result == null) {
      return Text(
        'Tap the button below to fetch your real-time GPS location 🛰️',
        style: TextStyle(color: Colors.white.withOpacity(0.8), fontSize: 14),
      );
    }

    // Error state
    if (!_result!.isSuccess) {
      return Container(
        padding: const EdgeInsets.all(12),
        decoration: BoxDecoration(
          color: Colors.red.withOpacity(0.18),
          borderRadius: BorderRadius.circular(10),
          border: Border.all(color: Colors.red.withOpacity(0.4)),
        ),
        child: Row(
          children: [
            const Icon(Icons.warning_amber_rounded, color: Colors.orange, size: 20),
            const SizedBox(width: 8),
            Expanded(
              child: Text(
                _result!.errorMessage!,
                style:
                    const TextStyle(color: Colors.white, fontSize: 12.5, height: 1.5),
              ),
            ),
          ],
        ),
      );
    }

    // Success state
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 12),
      decoration: BoxDecoration(
        color: Colors.white.withOpacity(0.14),
        borderRadius: BorderRadius.circular(12),
      ),
      child: Column(
        children: [
          _infoRow(Icons.explore_rounded, 'Latitude',
              _result!.lat!.toStringAsFixed(6)),
          _divider(),
          _infoRow(Icons.explore_outlined, 'Longitude',
              _result!.lng!.toStringAsFixed(6)),
          if (_result!.city != null && _result!.city!.isNotEmpty) ...[
            _divider(),
            _infoRow(Icons.location_city_rounded, 'City', _result!.city!),
          ],
        ],
      ),
    );
  }

  Widget _divider() => const Divider(color: Colors.white24, height: 16);

  Widget _infoRow(IconData icon, String label, String value) {
    return Row(
      children: [
        Icon(icon, color: Colors.white70, size: 17),
        const SizedBox(width: 8),
        Text('$label: ',
            style: const TextStyle(color: Colors.white60, fontSize: 13)),
        Expanded(
          child: Text(
            value,
            style: const TextStyle(
                color: Colors.white, fontSize: 13, fontWeight: FontWeight.w700),
            overflow: TextOverflow.ellipsis,
          ),
        ),
      ],
    );
  }
}
