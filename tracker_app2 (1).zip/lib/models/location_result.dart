/// Data model for a GPS location result.
/// Holds coordinates, city name, loading state, and any error message.
class LocationResult {
  final double? lat;
  final double? lng;
  final String? city;
  final String? errorMessage;

  const LocationResult({
    this.lat,
    this.lng,
    this.city,
    this.errorMessage,
  });

  /// True when we have valid coordinates and no error
  bool get isSuccess => lat != null && lng != null && errorMessage == null;
}
