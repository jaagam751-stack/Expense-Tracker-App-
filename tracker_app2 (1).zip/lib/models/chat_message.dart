/// Data model for a single chat message.
/// Used by both the Chatbot UI and the ChatbotService.
class ChatMessage {
  final String text;
  final bool isUser; // true = user bubble (right), false = bot bubble (left)
  final DateTime timestamp;

  ChatMessage({
    required this.text,
    required this.isUser,
    DateTime? timestamp,
  }) : timestamp = timestamp ?? DateTime.now();
}
